#pragma once

namespace FormTest {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ txtName;
	private: System::Windows::Forms::TextBox^ txtContact;
	private: System::Windows::Forms::TextBox^ txtEmail;
	private: System::Windows::Forms::Button^ btnSubmit;

	private: System::Windows::Forms::Button^ btnReset;
	private: System::Windows::Forms::Button^ btnClose;




	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtName = (gcnew System::Windows::Forms::TextBox());
			this->txtContact = (gcnew System::Windows::Forms::TextBox());
			this->txtEmail = (gcnew System::Windows::Forms::TextBox());
			this->btnSubmit = (gcnew System::Windows::Forms::Button());
			this->btnReset = (gcnew System::Windows::Forms::Button());
			this->btnClose = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(37, 71);
			this->label1->Margin = System::Windows::Forms::Padding(6, 0, 6, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(188, 42);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Name";
			
			// 
			// label2
			// 
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(37, 144);
			this->label2->Margin = System::Windows::Forms::Padding(6, 0, 6, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(188, 42);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Email";
			// 
			// label3
			// 
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(37, 227);
			this->label3->Margin = System::Windows::Forms::Padding(6, 0, 6, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(188, 42);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Contact";
			// 
			// txtName
			// 
			this->txtName->Location = System::Drawing::Point(189, 62);
			this->txtName->Margin = System::Windows::Forms::Padding(6, 5, 6, 5);
			this->txtName->Multiline = true;
			this->txtName->Name = L"txtName";
			this->txtName->Size = System::Drawing::Size(246, 66);
			this->txtName->TabIndex = 3;
			// 
			// txtContact
			// 
			this->txtContact->Location = System::Drawing::Point(189, 221);
			this->txtContact->Margin = System::Windows::Forms::Padding(6, 5, 6, 5);
			this->txtContact->Multiline = true;
			this->txtContact->Name = L"txtContact";
			this->txtContact->Size = System::Drawing::Size(246, 63);
			this->txtContact->TabIndex = 4;
			// 
			// txtEmail
			// 
			this->txtEmail->Location = System::Drawing::Point(189, 138);
			this->txtEmail->Margin = System::Windows::Forms::Padding(6, 5, 6, 5);
			this->txtEmail->Multiline = true;
			this->txtEmail->Name = L"txtEmail";
			this->txtEmail->Size = System::Drawing::Size(246, 62);
			this->txtEmail->TabIndex = 5;
			// 
			// btnSubmit
			// 
			this->btnSubmit->Location = System::Drawing::Point(42, 328);
			this->btnSubmit->Margin = System::Windows::Forms::Padding(6, 5, 6, 5);
			this->btnSubmit->Name = L"btnSubmit";
			this->btnSubmit->Size = System::Drawing::Size(113, 43);
			this->btnSubmit->TabIndex = 6;
			this->btnSubmit->Text = L"Submit";
			this->btnSubmit->UseVisualStyleBackColor = true;
			this->btnSubmit->Click += gcnew System::EventHandler(this, &MyForm::btnSubmit_Click);
			// 
			// btnReset
			// 
			this->btnReset->Location = System::Drawing::Point(216, 328);
			this->btnReset->Margin = System::Windows::Forms::Padding(6, 5, 6, 5);
			this->btnReset->Name = L"btnReset";
			this->btnReset->Size = System::Drawing::Size(113, 43);
			this->btnReset->TabIndex = 7;
			this->btnReset->Text = L"Reset";
			this->btnReset->UseVisualStyleBackColor = true;
			// 
			// btnClose
			// 
			this->btnClose->Location = System::Drawing::Point(382, 328);
			this->btnClose->Margin = System::Windows::Forms::Padding(6, 5, 6, 5);
			this->btnClose->Name = L"btnClose";
			this->btnClose->Size = System::Drawing::Size(113, 43);
			this->btnClose->TabIndex = 8;
			this->btnClose->Text = L"Close";
			this->btnClose->UseVisualStyleBackColor = true;
			this->btnClose->Click += gcnew System::EventHandler(this, &MyForm::btnClose_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(15, 29);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(528, 395);
			this->Controls->Add(this->btnClose);
			this->Controls->Add(this->btnReset);
			this->Controls->Add(this->btnSubmit);
			this->Controls->Add(this->txtEmail);
			this->Controls->Add(this->txtContact);
			this->Controls->Add(this->txtName);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Margin = System::Windows::Forms::Padding(6, 5, 6, 5);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			//this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		private: System::Void btnSubmit_Click(System::Object^ sender, System::EventArgs^ e) {
			if (this->txtName->Text->Trim() == "") {
				MessageBox::Show("Please Enter Name", "Name Validation", MessageBoxButtons::OK, MessageBoxIcon::Error);
			}
			else if (this->txtEmail->Text->Trim() == "") {
				MessageBox::Show("Please Enter Email", "Email Validation", MessageBoxButtons::OK, MessageBoxIcon::Error);
			}
			else if (this->txtContact->Text->Trim() == "") {
				MessageBox::Show("Please Enter Contact", "Contact Validation", MessageBoxButtons::OK, MessageBoxIcon::Error);
			}
			else {
				MessageBox::Show("Data Submitted Successfully", "Sucess", MessageBoxButtons::OK, MessageBoxIcon::Information);
			}
		}
	private: System::Void btnReset_Click(System::Object^ sender, System::EventArgs^ e) {
		this->txtName->Text = "";
		this->txtEmail->Text = "";
		this->txtContact->Text = "";


	}
private: System::Void btnClose_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Close();

}

	   //private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
		  // // This is where you can add any code to execute when the form loads.
	   //}

};
}
